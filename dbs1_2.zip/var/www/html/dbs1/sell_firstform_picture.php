<html>
  <meta http-equiv="Content-Type" 
            content="text/html; charset=utf8">
<body>

画像の登録を行ってください。<br>
<br>
<form enctype="multipart/form-data" action="./sell_secondform_picupload_and_detail.php" method="POST">
    <input name="upfile" type="file" />
    <input type="submit" value="送信" />
</form>
</body>
</html>
