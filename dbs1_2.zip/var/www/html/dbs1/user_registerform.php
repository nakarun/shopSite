<html>
<head>
  <title>register</title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
<form method="post" action="user_registerexecution.php">
	userName:<input type="text" name="user_name" size="18"><br>
	Password:<input type="password" name="user_password" size="18">
	<input type="submit" value="送信">
</form>
</body>
</html>
